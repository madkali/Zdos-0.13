# sdct - test SD Card

This program stress-tests a SD card by repeatedly reading and writing to it and
verify that data stays the same.
